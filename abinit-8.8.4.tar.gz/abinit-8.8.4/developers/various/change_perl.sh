# Copyright (C) 1998-2018 ABINIT group (XG)
 sed -e 's&#CODE_PAR&$CODE_PAR&' Utilities/,perl_tmp > Utilities/,perl_location_command
