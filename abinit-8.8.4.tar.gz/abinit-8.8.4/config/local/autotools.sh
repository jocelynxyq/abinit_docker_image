# Autotools version information
abi_m4_version="010416"
abi_ac_version="026900"
abi_am_version="011304"
abi_lt_version="020402"
