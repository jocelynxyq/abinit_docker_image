---
description: How to use the Learn-of-the-flight feature
authors: XG
---
<!--- This is the source file for this topics. Can be edited. -->

This page gives hints on how to use the Learn-of-the-flight feature with the ABINIT package.

## Introduction

Under development, for experts only.


## Related Input Variables

{{ related_variables }}

## Selected Input Files

{{ selected_input_files }}

