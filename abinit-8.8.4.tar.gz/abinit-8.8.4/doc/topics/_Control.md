---
description: How to control the flow of ABINIT
authors: XG
---
<!--- This is the source file for this topics. Can be edited. -->

This page gives hints on how to control the flow of ABINIT with the ABINIT package.

## Introduction

A few input variables governs the possible stopping of ABINIT, or modify
details of the ABINIT flow for specific cases.

## Related Input Variables

{{ related_variables }}

## Selected Input Files

{{ selected_input_files }}

